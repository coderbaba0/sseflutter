const express = require('express');

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS (Cross-Origin Resource Sharing)
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    next();
});
let connectionId = 0; // Assuming you have a way to generate unique connection IDs
let messageid = 100;
// Route for SSE endpoint
app.get('/events', (req, res) => {
    // Set headers for SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    
    // Send a dummy message every 5 seconds
   
    const intervalId = setInterval(() => {
        const currentTime = new Date().toISOString();
        // Generate a unique message ID
 messageid++;
        const messageObject = {
            connectionId: connectionId, // Add connection ID
            event: 'message', // Add event type
            message: `Hello ${getRandomName()}! Current temperature is ${getRandomTemperature()}°C.`,
            timestamp: currentTime,
            messageId:messageid
        };
        const messageString = JSON.stringify(messageObject);
        res.write(`id: ${connectionId}\n`); // Send connection ID as part of SSE event
        res.write(`event: message\n`); // Send event type as part of SSE event
        res.write(`data: ${messageString}\n\n`);
    }, 5000);
    
    // Increment connection ID for the next connection
    connectionId++;

    // Handle client disconnection
    req.on('close', () => {
        clearInterval(intervalId);
        console.log('Client disconnected');
    });
});
// Helper function to get a random name
function getRandomName() {
    const names = ['Kamal', 'Sumit', 'Zaid', 'Ajay', 'Shubham'];
    return names[Math.floor(Math.random() * names.length)];
}

// Helper function to get a random temperature
function getRandomTemperature() {
    return Math.floor(Math.random() * 30) + 10; // Random temperature between 10°C and 39°C
}

// Route handler for the root URL
app.get('/', (req, res) => {
    res.send('Server is running. Use /events for SSE notifications.');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
